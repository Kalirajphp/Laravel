## EMI Process

steps to configure the project

1. clone the project from github
2. config/check the DB details
3. update the composer

steps to run the project

1. Run the migrations using artisan command(php artisan migrate)
2. seed the data using artisan command(php artisan db:seed)
3. run the project with 'php artisan serve' and open new CMD for 'npm run dev'

login to the project

 username: developer
 
 password: Test@Password123#

 if you want to register then you can also register when click on the register link
 
 for the refence SQL file also included in to the project folder
## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).

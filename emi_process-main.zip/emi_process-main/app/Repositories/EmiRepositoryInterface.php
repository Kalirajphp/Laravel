<?php

namespace App\Repositories;

interface EmiRepositoryInterface
{
    public function all();

    public function emidetails();

}